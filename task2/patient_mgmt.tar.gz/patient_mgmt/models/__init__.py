# -*- coding: utf-8 -*-

from . import (patient, doctor, disease)