# -*- coding: utf-8 -*-
from flectra import api, fields, models

class DoctorData(models.Model):
    _name="doctor.data"

    name = fields.Char(string="doctor Name")
    appoimnt_date = fields.Date(string="available on", required=True)
   
    disease_ids = fields.Many2many("disease.data","disease_doctore_rel","doctore_id","disease_id",string="specialist_on")


    patient_line = fields.One2many("patient.data","doctore_id",string="patient name")


    patient_req = fields.Selection([('sc','success'),
                                    ('pn','pending'),
                                    ('rj','rejected')], string="status", default="sc")

   

    def state_pending(self):
        self.patient_req = "pn"
   
    def state_rejected(self):
        self.patient_req = 'rj'

    def state_confirm(self):
        self.patient_req = 'sc'


    #     self.patient_req

    #patient_ids= fields.Many2many("patient.data","patient_doctore_rel","doctore_id","patient_id",string="select patient")

"""
    @api.onchange("doctore_id")
    def onchange_store_data(self):
        print("---------------patient / name, ID /----------------", self.name, self.doctore_id)

        self.appoimnt_date = self.patient_id.appoimnt_date


        fields.Selection([('T1D','Type 1 Diabetes'),
                             ('MS','Multiple Sclerosis'),
                             ('UC','Crohns & Colitis'),
                             ('lupus','Lupus'),
                             ('type-5','rheumatoid-arth'),
                             ('type-6','Allergies & Asthma'),
                             ('type-7','Celiac Disease'),
                             ('type-8','Relapsing Polychondritis'),
                             ('type-9','Liver Disease'),
                             ('type-10','Infectious Diseases'),
                             ],)
"""
